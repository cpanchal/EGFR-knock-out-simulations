Notes:

- The basic model of EGFR pathway is written in COPASI and the folder contains 2 identical copasi files of the basic model. This files are loaded in the java code.

- The java code executes the  basic model by creating and simulating all the possible  knock-out mutant models.

- In order to run this java code COPASI java bindings are mandatory. 
  They are available here: http://www.copasi.org/tiki-index.php?page=DownloadNonCommercialBindings

- To produce logicome for different values of EGF and EGFR, the changes should be done in the given COPASI files.