Note:

- This folder contains the simulation data of the knock-out models. 

- Simulation data are collected first without binarizing and then they are discretized.

- The discretized data are in the form of "0" and "1", and they are imported in the tool "LogicFriday" in order to generate Logicome.
