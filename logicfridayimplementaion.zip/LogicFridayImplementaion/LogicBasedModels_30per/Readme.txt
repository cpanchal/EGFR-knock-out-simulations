Notes:

- The logicome files are generated from the COAPSI simulations conducted for the threshold percentage of 30%, EGF concentration of 4981 molecules/pl and EGFR concentration of 50000 molecules/pl.

- In order to generate the logicome in LogicFriday, the binarized knock-out mutants simulation results are imported as a truth table in the tool "LogicFriday" and then mapped to gates.

- The  simulation results file is transformed into txt files with minor modifications in the species names in-order to avoid LogicFriday-error caused due to long/inappropriate names.
