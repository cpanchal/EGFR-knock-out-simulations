Notes:

- The logicome files are generated from the copasi simulations conducted for the EGF concentration of 4981 molecules/pl and EGFR concentration of 50000 molecules/pl.

- The copasi knock-out simulation results are collected and then binarised. This binarised results are imported in LogicFriday in-order to generate the logicome.

- The file  containing copasi knock-out simulation data, is transformed into txt files with minor modifications in the species names in-order to avoid LogicFriday-error caused due to long/inappropriate names.

- The generated txt file is imported as truth tables in LogicFriday.

- In our experiment we have assumed that the knock-out mutants data for 70 knock-out mutants are not available. 
Hence, the boolean circuit is generated for the rest 186 knock-out mutants.

