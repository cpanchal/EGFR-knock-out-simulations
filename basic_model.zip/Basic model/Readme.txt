Notes:

- The folder contains the basic model of EGFR (Epidermal Growth Factor Receptor) pathway.
  This is a reaction based-model written in COPASI (COmplex PAth SImulator).

- More information about COPASI are available here: http://www.copasi.org/static/Copasi_Tutorial/Tutorial.html

